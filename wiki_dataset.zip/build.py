"""Turn the wiki vault into a JSONL dataset: one record per note section.

usage: python3 wiki_dataset/build.py   (from project root) -> wiki_dataset/wiki.jsonl
Each record: id, dir, path, title, section, tags, updated, retraction, text.
Filter downstream on `dir` / `retraction` (e.g. drop log/sessions or any ⛔ chunk).
"""
import json, re, pathlib, yaml

WIKI = pathlib.Path('Paper/References/md_converted/wiki')
OUT = pathlib.Path('wiki_dataset/wiki.jsonl')
SKIP = {'sources', '.obsidian', 'canvases'}   # sources/ = raw PDF dumps of other people's papers


def sections(body):
    """Split on level-2 headings; preamble before the first '## ' is section ''."""
    parts = re.split(r'^## +(.+)$', body, flags=re.M)
    yield '', parts[0]
    yield from zip(parts[1::2], parts[2::2])


def records():
    for p in sorted(WIKI.rglob('*.md')):
        rel = p.relative_to(WIKI)
        if rel.parts[0] in SKIP:
            continue
        raw = p.read_text(encoding='utf-8')
        meta, body = {}, raw
        if raw.startswith('---\n') and (end := raw.find('\n---', 4)) > 0:
            try:
                meta = yaml.safe_load(raw[4:end]) or {}
            except yaml.YAMLError:
                pass            # ponytail: broken frontmatter stays in text, metadata empty
            body = raw[end + 4:].lstrip('\n')
        m = re.search(r'^# +(.+)$', body, re.M)
        title = m.group(1).strip() if m else p.stem
        for i, (sec, text) in enumerate(sections(body)):
            text = text.strip()
            if len(text) < 40:      # heading-only or empty stubs
                continue
            yield {
                'id': f'{rel.with_suffix("")}#{i}',
                'dir': rel.parts[0] if len(rel.parts) > 1 else '.',
                'path': str(rel),
                'title': title,
                'section': sec.strip(),
                'tags': meta.get('tags') or [],
                'updated': str(meta.get('updated') or meta.get('created') or ''),
                'retraction': '⛔' in text,
                'text': text,
            }


if __name__ == '__main__':
    n = 0
    with OUT.open('w', encoding='utf-8') as f:
        for r in records():
            f.write(json.dumps(r, ensure_ascii=False) + '\n')
            n += 1
    # self-check: every record round-trips and ids are unique
    rows = [json.loads(l) for l in OUT.open(encoding='utf-8')]
    assert len(rows) == n and len({r['id'] for r in rows}) == n
    assert not any(r['path'].startswith('sources/') for r in rows)
    print(f'wrote {OUT}: {n} records')
